Hi, please contact me before any commercial use. 
My fonts for free use allowed only in personal project , non-profit and charity use.

Please Purchase for commercial project
https://www.creativefabrica.com/designer/pentype-studio/

Thank you

